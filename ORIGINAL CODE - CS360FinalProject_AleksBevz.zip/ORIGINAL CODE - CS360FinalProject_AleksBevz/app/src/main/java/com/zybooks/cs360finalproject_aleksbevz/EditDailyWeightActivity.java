package com.zybooks.cs360finalproject_aleksbevz;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.ArrayList;
import java.util.List;

public class EditDailyWeightActivity extends AppCompatActivity {

    // Widgets
    private EditText mDateInput;
    private EditText mWeightInput;
    private Button mSaveButton;

    // Variables and objects
    public static final String EXTRA_USERNAME = "com.zybooks.weighttracker.username";
    private Menu mMenu;
    private String mUsername;
    private WeightTrackerDatabase mWeightTrackerDB;
    private DailyWeight mDailyWeight;
    private List<DailyWeight> mDailyWeightList = new ArrayList<>();

    // TextWatcher for dynamically enabling/disabling the add button
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged (CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // Enable button when user enters text
            if (s.length() > 0) {
                mSaveButton.setEnabled(true);
            }
            // Disable button if no text
            else {
                mSaveButton.setEnabled(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_daily_weight);

        mDateInput = findViewById(R.id.dateEditText);
        mWeightInput = findViewById(R.id.weightEditText);
        mSaveButton = findViewById(R.id.saveButton);

        mWeightTrackerDB = WeightTrackerDatabase.getInstance(getApplicationContext());

        // Get username from WeightDisplayActivity so daily weight is associated with current user
        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USERNAME);

        // Set text changed listener for the EditText
        // TODO - make sure both edit text fields have text before button is enabled
        mWeightInput.addTextChangedListener(textWatcher);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        mMenu = menu;
        return super.onCreateOptionsMenu(menu);
    }

    // Saves the daily weight
    public void onSaveClick(View view) {
        String date = mDateInput.getText().toString();
        String dailyWeightVal = mWeightInput.getText().toString();

        // Create new daily weight object then update existing entry for the specific id
        // TODO - fix; need to reset date and weight of current daily weight, then call updateDailyWeight
        mDailyWeight = new DailyWeight(date, dailyWeightVal, mUsername);
        mWeightTrackerDB.updateDailyWeight(mDailyWeight);
        finish();
    }
}