package com.zybooks.cs360finalproject_aleksbevz;

public class UserLogin {

    private String mUsername;
    private String mPassword;
    private String mPhoneNumber;

    public UserLogin() {}

    public UserLogin(String username, String password, String phoneNumber) {
        mUsername = username;
        mPassword = password;
        mPhoneNumber = phoneNumber;
    }

    public String getUsername() {
        return mUsername;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        mPassword = password;
    }

    public String getPhoneNumber() {
        return mPhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        mPhoneNumber = phoneNumber;
    }
}
