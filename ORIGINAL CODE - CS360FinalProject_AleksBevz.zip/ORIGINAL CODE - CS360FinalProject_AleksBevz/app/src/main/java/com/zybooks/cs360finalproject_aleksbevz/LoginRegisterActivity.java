package com.zybooks.cs360finalproject_aleksbevz;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class LoginRegisterActivity extends AppCompatActivity {

    private EditText mUsernameText;
    private EditText mPasswordText;
    private TextView mMessageText;
    private Button mLoginButton;
    private Button mRegisterButton;

    private WeightTrackerDatabase mWeightTrackerDB;

    // TextWatcher for dynamically enabling/disabling the Login and Register buttons
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged (CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            //enable button when user enters text
            if (s.length() > 0) {
                mLoginButton.setEnabled(true);
                mRegisterButton.setEnabled(true);
            }
            // when there is no text, disable button
            else {
                mLoginButton.setEnabled(false);
                mRegisterButton.setEnabled(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_register);

        // Assign widgets to fields
        mUsernameText = findViewById(R.id.usernameText);
        mPasswordText = findViewById(R.id.passwordText);
        mMessageText = findViewById(R.id.messageText);
        mLoginButton = findViewById(R.id.loginButton);
        mRegisterButton = findViewById(R.id.registerButton);

        mWeightTrackerDB = WeightTrackerDatabase.getInstance(getApplicationContext());

        // Set text changed listener for the password EditText field
        // TODO: make sure mUsernameText also has text before the buttons are enabled
        mPasswordText.addTextChangedListener(textWatcher);
    }

    // onClick method for the Login button - authenticates entered credentials
    public void loginClick(View view){
        String userName = mUsernameText.getText().toString();
        String password = mPasswordText.getText().toString();

        // To check for successful authentication (ensures user was found in db)
        boolean userFound = mWeightTrackerDB.getUserByCredentials(userName, password);

        if (userFound == true) {
            // Launch next activity
            Intent intent = new Intent(this, WeightDisplayActivity.class);
            intent.putExtra(WeightDisplayActivity.EXTRA_USERNAME, userName);
            startActivity(intent);
        }
        else {
            // Display error message
            mMessageText.setText(R.string.invalid_credentials);
            mMessageText.setVisibility(View.VISIBLE);

            // Clear EditText fields so user can try again
            mUsernameText.setText("");
            mPasswordText.setText("");
        }


    }


    // onClick method for the Register button - adds new user to user database
    public void registerClick(View view){

        String userName = mUsernameText.getText().toString();
        String password = mPasswordText.getText().toString();
        String phoneNumber = "";

        //create new user object with username and pw
        // set phone number to empty string; will be added later if user chooses
        UserLogin userLogin = new UserLogin(userName, password, phoneNumber);


        // To check for successful user add
        boolean successfulUserAdd = mWeightTrackerDB.addUser(userLogin);

        // If user is added, display message that prompts login
        if (successfulUserAdd == true) {
            mMessageText.setText(R.string.successful_user_add);
            mMessageText.setVisibility(View.VISIBLE);
        }
        // If user cannot be added (ie due to duplicate username), display error message
        else {
            mMessageText.setText(R.string.unsuccessful_user_add);
            mMessageText.setVisibility(View.VISIBLE);
        }

        // Clear EditText fields so user can try again
        mUsernameText.setText("");
        mPasswordText.setText("");

    }
}