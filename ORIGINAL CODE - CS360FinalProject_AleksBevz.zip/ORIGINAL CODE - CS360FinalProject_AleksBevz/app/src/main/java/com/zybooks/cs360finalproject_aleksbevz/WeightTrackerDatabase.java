package com.zybooks.cs360finalproject_aleksbevz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

public class WeightTrackerDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 3;
    private static final String DATABASE_NAME = "userLogin.db";
    private static final String TAG = "WeightTrackerDatabase";

    private static WeightTrackerDatabase mWeightTrackerDB;

    public static WeightTrackerDatabase getInstance(Context context) {
        if (mWeightTrackerDB == null) {
            mWeightTrackerDB = new WeightTrackerDatabase(context);
        }
        return mWeightTrackerDB;
    }

    private WeightTrackerDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_PHONE = "phone";
    }

    private static final class GoalWeightTable {
        private static final String TABLE = "goal_weight";
        private static final String COL_USERNAME = "username";
        private static final String COL_GOAL_WEIGHT = "goal_weight";

    }

    private static final class DailyWeightTable {
        private static final String TABLE = "daily_weight";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
        private static final String COL_USERNAME = "username";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the User table; username is primary key to ensure unique logins
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_USERNAME + " primary key, " +
                UserTable.COL_PASSWORD + ", " +
                UserTable.COL_PHONE + " )");

        // Create goal weight table with username as primary key to ensure each user only
        //  has one goal weight at a time
        db.execSQL("create table " + GoalWeightTable.TABLE + " (" +
                GoalWeightTable.COL_USERNAME + " primary key, " +
                GoalWeightTable.COL_GOAL_WEIGHT + " )");

        // Create daily weight table with foreign key that cascade deletes
        db.execSQL("create table " + DailyWeightTable.TABLE + " (" +
                DailyWeightTable.COL_ID + " integer primary key autoincrement, " +
                DailyWeightTable.COL_DATE + ", " +
                DailyWeightTable.COL_WEIGHT + ", " +
                DailyWeightTable.COL_USERNAME + ", " +
                "foreign key(" + DailyWeightTable.COL_USERNAME + ") references " +
                UserTable.TABLE + "(" + UserTable.COL_USERNAME + ") on delete cascade)");

    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + GoalWeightTable.TABLE);
        db.execSQL("drop table if exists " + DailyWeightTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    // Add a new user to the database
    public boolean addUser(UserLogin userLogin) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, userLogin.getUsername());
        values.put(UserTable.COL_PASSWORD, userLogin.getPassword());
        values.put(UserTable.COL_PHONE, userLogin.getPhoneNumber());
        long id = db.insert(UserTable.TABLE, null, values);
        return id != -1;
    }

    // Get username and password for authentication checks
    public boolean getUserByCredentials(String username, String password) {
        boolean credentialsFound;
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + UserTable.TABLE + " where username = ? and password = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username, password });
        if (cursor.moveToFirst()) {
            credentialsFound = true;
        }
        else {
            credentialsFound = false;
        }
        cursor.close();

        return credentialsFound;
    }

    // Get the user data by username only - used for SMS permission/sending feature
    public UserLogin getUserByUsername(String username) {
        UserLogin userLogin = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE + " where "
                + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username });

        if (cursor.moveToFirst()) {
            userLogin = new UserLogin();
            userLogin.setUsername(cursor.getString(0));
            userLogin.setPassword(cursor.getString(1));
            userLogin.setPhoneNumber(cursor.getString(2));
        }
        cursor.close();
        return userLogin;
    }


    // Updates user login
    public void updateUser(UserLogin userLogin) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, userLogin.getUsername());
        values.put(UserTable.COL_PASSWORD, userLogin.getPassword());
        values.put(UserTable.COL_PHONE, userLogin.getPhoneNumber());
        db.update(UserTable.TABLE, values,
                UserTable.COL_USERNAME + " = ?", new String[] { userLogin.getUsername() });
    }

    // Deletes user from the database - not currently used
    /*
    public void deleteUser(UserLogin userLogin) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(UserTable.TABLE,
                UserTable.COL_USERNAME + " = ?", new String[] { userLogin.getUsername() });
    }
     */


    // For adding a goal weight to the goal weight table
    public boolean addGoalWeight(GoalWeight goalWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalWeightTable.COL_USERNAME, goalWeight.getUsername());
        values.put(GoalWeightTable.COL_GOAL_WEIGHT, goalWeight.getGoalWeight());
        long id = db.insert(GoalWeightTable.TABLE, null, values);
        return id != -1;
    }

    // Pulls the Goal Weight data from db table
    public GoalWeight getGoalWeight(String username) {
        GoalWeight goalWeight = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + GoalWeightTable.TABLE + " where "
                + GoalWeightTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username });

        if (cursor.moveToFirst()) {
            goalWeight = new GoalWeight();
            goalWeight.setUsername(cursor.getString(0));
            goalWeight.setGoalWeight(cursor.getString(1));
        }
        cursor.close();
        return goalWeight;
    }


    // Updates a user's existing goal weight
    public void updateGoalWeight(GoalWeight goalWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalWeightTable.COL_USERNAME, goalWeight.getUsername());
        values.put(GoalWeightTable.COL_GOAL_WEIGHT, goalWeight.getGoalWeight());
        db.update(GoalWeightTable.TABLE, values,
                GoalWeightTable.COL_USERNAME + " = ?", new String[] { goalWeight.getUsername() });
    }


    // Delete a user's goal weight
    public void deleteGoalWeight(String username) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(GoalWeightTable.TABLE,
                GoalWeightTable.COL_USERNAME + " = ?", new String[] { username });
    }


    // Adds a new daily weight to the daily weight table for a given user
    public boolean addDailyWeight(DailyWeight dailyWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DailyWeightTable.COL_DATE, dailyWeight.getDate());
        values.put(DailyWeightTable.COL_WEIGHT, dailyWeight.getDailyWeight());
        values.put(DailyWeightTable.COL_USERNAME, dailyWeight.getUsername());
        long id = db.insert(DailyWeightTable.TABLE, null, values);
        dailyWeight.setId(id);

        return id != -1;
    }

    // Get the Daily Weight data from db table
    public List<DailyWeight> getDailyWeights(String username) {
        List<DailyWeight> dailyWeights = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + DailyWeightTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username });
        if (cursor.moveToFirst()) {
            do {
                DailyWeight dailyWeight = new DailyWeight();
                dailyWeight.setId(cursor.getLong(0));
                dailyWeight.setDate(cursor.getString(1));
                dailyWeight.setDailyWeight(cursor.getString(2));
                dailyWeight.setUsername(cursor.getString(3));
                dailyWeights.add(dailyWeight);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return dailyWeights;
    }

    // Update a daily weight entry
    public void updateDailyWeight(DailyWeight dailyWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DailyWeightTable.COL_ID, dailyWeight.getId());
        values.put(DailyWeightTable.COL_DATE, dailyWeight.getDate());
        values.put(DailyWeightTable.COL_WEIGHT, dailyWeight.getDailyWeight());
        values.put(DailyWeightTable.COL_USERNAME, dailyWeight.getUsername());
        db.update(DailyWeightTable.TABLE, values,
                DailyWeightTable.COL_ID + " = " + dailyWeight.getId(), null);
    }


    // Delete a daily weight entry
    public void deleteDailyWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(DailyWeightTable.TABLE,
                DailyWeightTable.COL_ID + " = " + id, null);
    }


}
