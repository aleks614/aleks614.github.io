package com.zybooks.cs360finalproject_aleksbevz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class smsPermissionActivity extends AppCompatActivity {

    // Widgets
    private Menu mMenu;
    private Button mYesButton;
    private Button mNoButton;
    private TextView mEnterPhoneText;
    private EditText mEditPhone;
    private Button mSaveButton;

    private UserLogin mUserLogin;
    private String mUsername;
    private String mPermissionGranted;
    private WeightTrackerDatabase mWeightTrackerDB;
    public static final String EXTRA_USERNAME = "com.zybooks.weighttracker.username";
    public static final String EXTRA_PERMISSION_GRANTED = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        //Assign widgets
        mYesButton = findViewById(R.id.buttonYes);
        mNoButton = findViewById(R.id.buttonNo);
        mSaveButton = findViewById(R.id.buttonSave);
        mEditPhone = findViewById(R.id.phoneEditText);


        // Get username from activity so phone # is associated with current user
        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USERNAME);

        mWeightTrackerDB = WeightTrackerDatabase.getInstance(getApplicationContext());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        mMenu = menu;
        return super.onCreateOptionsMenu(menu);
    }

    public void onYesClick(View view){

        // Check to see if permission has been granted, else request permission
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        1);
            }
        }

        // display widgets for user to enter and save phone number
        mEditPhone.setVisibility(View.VISIBLE);
        mSaveButton.setVisibility(View.VISIBLE);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(getApplicationContext(), "SMS notifications enabled.",
                            Toast.LENGTH_LONG).show();
                } else {

                    return;
                }
            }
        }

    }

    // If user does not enable SMS notifications, send string "no" back to parent activity;
    // sendSMS method will not execute
    public void onNoClick(View view){
        mPermissionGranted = "no";
        Intent intent = new Intent();
        intent.putExtra(EXTRA_PERMISSION_GRANTED, mPermissionGranted);
        setResult(RESULT_OK, intent);
        finish();
    }

    // onclick method to save user's entered phone number
    public void onSaveClick(View view) {
        mPermissionGranted = "yes";
        String phoneNumber = mEditPhone.getText().toString();
        mUserLogin = mWeightTrackerDB.getUserByUsername(mUsername);
        mUserLogin.setPhoneNumber(phoneNumber);
        mWeightTrackerDB.updateUser(mUserLogin);

        Intent intent = new Intent();
        intent.putExtra(EXTRA_PERMISSION_GRANTED, mPermissionGranted);
        setResult(RESULT_OK, intent);
        finish();
    }
}