package com.zybooks.cs360finalproject_aleksbevz;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class WeightDisplayActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_SMS = 0;
    // Widgets
    private ImageButton mEditGoalButton;
    private TextView mGoalWeightTextView;

    // Variables and objects
    private Menu mMenu;
    private WeightTrackerDatabase mWeightTrackerDB;
    private GoalWeight mGoalWeight = new GoalWeight();
    private String mUsername;
    public static final String EXTRA_USERNAME = "com.zybooks.weighttracker.username";
    private List<DailyWeight> mDailyWeights = new ArrayList<>();
    private DailyWeight mDailyWeight;
    private RecyclerView mRecyclerView;
    private RecyclerViewAdapter mRecyclerViewAdapter;
    private boolean mSMSPermitted = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_display);

        // Assign widgets to fields
        mEditGoalButton = findViewById(R.id.editGoalImageButton);
        mGoalWeightTextView = findViewById(R.id.goalWeightTextView);

        // Hosting activity provides the username for the logged in user
        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USERNAME);

        mWeightTrackerDB = WeightTrackerDatabase.getInstance(getApplicationContext());

        compareGoalWeight();
        displayGoalWeight();
        displayDailyWeight();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        mMenu = menu;
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_notifications:
                Intent intent = new Intent(WeightDisplayActivity.this, smsPermissionActivity.class);
                intent.putExtra(smsPermissionActivity.EXTRA_USERNAME, mUsername);
                // TODO - below method is deprecated; need to replace with current method
                startActivityForResult(intent, REQUEST_CODE_SMS);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode== RESULT_OK && requestCode == REQUEST_CODE_SMS) {
            String smsPermissionGranted = data.getStringExtra(smsPermissionActivity.EXTRA_PERMISSION_GRANTED);
            if (smsPermissionGranted=="yes") {
                mSMSPermitted = true;
            } else {
                mSMSPermitted = false;
            }
        }
    }

    @Override
    protected void onResume(){
        super.onResume();
        displayGoalWeight();
        displayDailyWeight();
        compareGoalWeight();
    }

    @Override
    protected void onStart(){
        super.onStart();
        displayGoalWeight();
        displayDailyWeight();
        compareGoalWeight();
    }

    @Override
    protected void onPause(){
        super.onPause();
    }

    @Override
    protected void onStop(){
        super.onStop();
    }

    private List<DailyWeight> loadDailyWeights() {
        return mWeightTrackerDB.getDailyWeights(mUsername);
    }


    // Check for goal weight reached
    // call sendSMS only if permission is granted and if goal weight equals daily weight
    public void compareGoalWeight() {
        String date;
        String dailyWeight;
        mGoalWeight = mWeightTrackerDB.getGoalWeight(mUsername);

        if (mSMSPermitted==true && mDailyWeights.size() != 0) {

            // Loop through daily weights to check for goal weight reached
            for (int i = 0; i < mDailyWeights.size(); i++) {
                mDailyWeight = new DailyWeight();
                mDailyWeight = mDailyWeights.get(i);

                date = mDailyWeight.getDate();
                dailyWeight = mDailyWeight.getDailyWeight();

                // Checking for equality for daily and goal weight
                if (dailyWeight.equals(mGoalWeight)) {
                    sendSMS(date, mGoalWeight);
                }
            }
        }
    }

    // to send SMS when goal weight is reached
    public void sendSMS(String date, GoalWeight goalWeight) {

        UserLogin userLogin = new UserLogin();
        userLogin = mWeightTrackerDB.getUserByUsername(mUsername);
        String phoneNo = userLogin.getPhoneNumber();
        String smsMessage = "Congrats! On " + date + ", you reached your goal weight of " +
                goalWeight + "!";
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, null, smsMessage, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    // onClick method to add OR edit goal weight
    public void editGoalWeightClick(View view) {
        Intent intent = new Intent(this, GoalWeightActivity.class);
        intent.putExtra(GoalWeightActivity.EXTRA_USERNAME, mUsername);
        startActivity(intent);
    }

    // onClick method to delete goal weight
    public void deleteGoalWeightClick(View view) {
        mWeightTrackerDB.deleteGoalWeight(mUsername);
        displayGoalWeight();
    }


    // method to display the user's goal weight
    public void displayGoalWeight() {
        String goalText;
        mGoalWeight = mWeightTrackerDB.getGoalWeight(mUsername);
        if (mGoalWeight != null) {
            goalText = mGoalWeight.getGoalWeight();
        } else {
            goalText = "";
        }

        mGoalWeightTextView.setText(goalText);
    }


    // onClick method to add new daily weight data
    public void addNewDailyWeightClick(View view) {
        Intent intent = new Intent(this, DailyWeightActivity.class);
        intent.putExtra(DailyWeightActivity.EXTRA_USERNAME, mUsername);
        startActivity(intent);
    }

    // To display the recycler view of daily weight data
    private void displayDailyWeight() {
        mRecyclerView = findViewById(R.id.recyclerView);

        // Shows the available daily weights
        mRecyclerViewAdapter = new RecyclerViewAdapter(this, loadDailyWeights());
        mRecyclerView.setAdapter(mRecyclerViewAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }



}