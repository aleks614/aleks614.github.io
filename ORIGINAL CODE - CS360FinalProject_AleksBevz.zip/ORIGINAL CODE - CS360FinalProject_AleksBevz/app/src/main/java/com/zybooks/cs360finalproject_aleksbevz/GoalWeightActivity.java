package com.zybooks.cs360finalproject_aleksbevz;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class GoalWeightActivity extends AppCompatActivity {

    // Widgets
    private EditText mGoalWeightInput;
    private Button mSaveButton;

    // Vars and objects
    public static final String EXTRA_USERNAME = "com.zybooks.weighttracker.username";
    private Menu mMenu;
    private String mUsername;
    private WeightTrackerDatabase mWeightTrackerDB;
    private GoalWeight mGoalWeight;


    // TextWatcher for dynamically enabling/disabling the save button
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged (CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // Enable button when user enters text
            if (s.length() > 0) {
                mSaveButton.setEnabled(true);
            }
            // Disable button if no text
            else {
                mSaveButton.setEnabled(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        mGoalWeightInput = findViewById(R.id.weightEditText);
        mSaveButton = findViewById(R.id.goalSaveButton);

        mWeightTrackerDB = WeightTrackerDatabase.getInstance(getApplicationContext());

        // Get username from WeightDisplayActivity so goal weight is associated with current user
        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USERNAME);

        // Set text changed listener for the EditText
        mGoalWeightInput.addTextChangedListener(textWatcher);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        mMenu = menu;
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // TODO: fix up bar - does not navigate back to WeightDisplayActivity
            //  though it is marked as parent in Manifest
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Save user's entered goal weight
    public void onGoalSaveClick(View view) {
        String goalWeightVal = mGoalWeightInput.getText().toString();
        mGoalWeight = mWeightTrackerDB.getGoalWeight(mUsername);
        if ( mGoalWeight == null) {
            // Add new Goal Weight if none exists for user
            mGoalWeight = new GoalWeight(goalWeightVal, mUsername);
            mWeightTrackerDB.addGoalWeight(mGoalWeight);
        } else {
            // Update Goal Weight if user already has one
            mGoalWeight.setGoalWeight(goalWeightVal);
            mWeightTrackerDB.updateGoalWeight(mGoalWeight);
        }

        finish();
    }

}