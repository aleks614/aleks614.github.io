package com.zybooks.cs360finalproject_aleksbevz;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private List<DailyWeight> mDailyWeightList = new ArrayList<>();
    private Context mContext;
    private WeightTrackerDatabase mWeightTrackerDB;

    // Default constructor
    public RecyclerViewAdapter(Context context, List<DailyWeight> dailyWeightList) {
        mDailyWeightList = dailyWeightList;
        mContext = context;
    }

    @NonNull
    @org.jetbrains.annotations.NotNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull @org.jetbrains.annotations.NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_daily_weight, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull @org.jetbrains.annotations.NotNull RecyclerViewAdapter.ViewHolder holder, int position) {
        holder.bind(mDailyWeightList.get(position), position);


    }

    @Override
    public int getItemCount() {
        return mDailyWeightList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        // Widgets
        private DailyWeight mDailyWeight;
        private TextView mDateText;
        private TextView mWeightText;
        private ImageButton mEditButton;
        private ImageButton mDeleteButton;

        // Layouts
        private RelativeLayout mParentLayout;

        // variables
        private String mDate;
        private String mWeight;
        private long mId;
        private String mUsername;



        public ViewHolder(View itemView) {
            super(itemView);
            mContext = itemView.getContext();


            // Assign widgets and layouts to id's
            mDateText = itemView.findViewById(R.id.dateTextView);
            mWeightText = itemView.findViewById(R.id.weightTextView);
            mEditButton = itemView.findViewById(R.id.editImageButton);
            mDeleteButton = itemView.findViewById(R.id.deleteImageButton);
            mParentLayout = itemView.findViewById(R.id.rowDailyWeight);

        }

        public void bind(DailyWeight dailyWeight, int position) {
            mDailyWeight = dailyWeight;
            mDate = mDailyWeight.getDate();
            mWeight = mDailyWeight.getDailyWeight();
            mId = mDailyWeight.getId();
            mUsername = mDailyWeight.getUsername();

            mDateText.setText(mDate);
            mWeightText.setText(mWeight);

            mEditButton.setTag(mId);
            mDeleteButton.setTag(mId);

            // OnClick method to edit individual daily weight entries
            // TODO - fix this (currently display does not update; need to update daily weight in
            //  list, since the list is what is used in the recycler view display)
            mEditButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // intent to launch edit activity
                    Intent intent = new Intent(mContext, EditDailyWeightActivity.class);
                    intent.putExtra(EditDailyWeightActivity.EXTRA_USERNAME, mUsername);
                    mContext.startActivity(intent);

                    notifyItemChanged(position);
                }
            });

            // OnClick method to delete individual daily weight entries
            // TODO - fix this (currently app crashes when delete button is clicked and
            //  daily weight is not deleted from display, only from the DB; need to delete daily
            //  weight from list, since the list is what is used in the recycler view display)

            mDeleteButton.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    mWeightTrackerDB.deleteDailyWeight(mId);
                    notifyItemRemoved(position);
                }
            });

        }


    }

}
