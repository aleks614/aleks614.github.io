package com.zybooks.cs360finalproject_aleksbevz;

public class GoalWeight {

    // Private long mId;
    private String mGoalWeight;
    private String mUsername;

    public GoalWeight() {}

    public GoalWeight(String weight, String username) {
        mGoalWeight = weight;
        mUsername = username;
    }

    public void setGoalWeight(String weight) {
        mGoalWeight = weight;
    }

    public String getGoalWeight() {
        return mGoalWeight;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getUsername() {
        return mUsername;
    }
}
