// This file defines the dialog fragment that that is shown to users in LoginRegisterActivity
//   when they enter invalid credentials

package com.zybooks.cs360finalproject_aleksbevz;

import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class InvalidLoginDialogFragment extends DialogFragment {
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.error);                                            //title indicates error
        builder.setMessage(R.string.invalid_credentials);  //message explaining the error
        builder.setPositiveButton(R.string.ok, null);                         //only one button which will dismiss the dialog
        return builder.create();
    }
}
