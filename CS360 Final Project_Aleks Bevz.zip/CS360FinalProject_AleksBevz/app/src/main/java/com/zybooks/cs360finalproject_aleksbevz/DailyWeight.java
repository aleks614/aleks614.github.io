// This file is for the DailyWeight class, which defines the structure of a DailyWeight object
//   as well as the methods which may be used on a DailyWeight Object.
//     The DailyWeight object holds all pertinent data that is associated with a single daily weight entry made by the user.


package com.zybooks.cs360finalproject_aleksbevz;

public class DailyWeight {
    private long mId;
    private String mDate;
    private String mDailyWeight;
    private String mUsername;

    public DailyWeight() {}

    // constructor for DailyWeight objects
    public DailyWeight(String date, String weight, String username) {

        mDate = date;
        mDailyWeight = weight;
        mUsername = username;
    }

    // various methods used to set or get any of the parameters associated with a single DailyWeight object
    public void setId(long id) {
        mId = id;
    }

    public long getId() {
        return mId;
    }

    public void setDate(String date) {
        mDate = date;
    }

    public String getDate() {
        return mDate;
    }

    public void setDailyWeight(String weight) {
        mDailyWeight = weight;
    }

    public String getDailyWeight() {
        return mDailyWeight;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getUsername() {
        return mUsername;
    }

}
