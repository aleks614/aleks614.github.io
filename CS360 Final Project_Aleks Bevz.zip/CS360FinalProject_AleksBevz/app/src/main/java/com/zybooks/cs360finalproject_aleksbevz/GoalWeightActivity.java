// This file defines the GoalWeightActivity, which is the activity where users can add or edit their goal weight.

package com.zybooks.cs360finalproject_aleksbevz;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class GoalWeightActivity extends AppCompatActivity {

    // Widgets
    private EditText mGoalWeightInput;
    private Button mSaveButton;

    // Vars and objects
    public static final String EXTRA_USERNAME = "com.zybooks.weighttracker.username";
    private String mUsername;
    private WeightTrackerDatabase mWeightTrackerDB;
    private GoalWeight mGoalWeight;


    // TextWatcher for dynamically enabling/disabling the save button
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged (CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // Enable button when user enters text
            if (s.length() > 0) {
                mSaveButton.setEnabled(true);
            }
            // Disable button if no text
            else {
                mSaveButton.setEnabled(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        //assign widgets to fields
        mGoalWeightInput = findViewById(R.id.weightEditText);
        mSaveButton = findViewById(R.id.goalSaveButton);

        //get instance of db
        mWeightTrackerDB = WeightTrackerDatabase.getInstance(getApplicationContext());

        // Get username extra from WeightDisplayActivity so goal weight is associated with current user
        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USERNAME);

        // get goal weight object for user from db
        mGoalWeight = mWeightTrackerDB.getGoalWeight(mUsername);

        //if user already has a goal weight so (not null), display it in the edit text
        if (mGoalWeight != null) {
            mGoalWeightInput.setText(mGoalWeight.getGoalWeightValue());
            mSaveButton.setEnabled(true);  //since edit text has input, save button can be enabled
        }

        // Set text changed listener for the EditText
        mGoalWeightInput.addTextChangedListener(textWatcher);
    }


    // Save user's entered goal weight
    public void onGoalSaveClick(View view) {
        //store user input in goalWeightVal var
        String goalWeightVal = mGoalWeightInput.getText().toString();

        //get goal weight object for user from db
        mGoalWeight = mWeightTrackerDB.getGoalWeight(mUsername);

        // if user does not have a goal weight
        if (mGoalWeight == null) {
            // create new Goal Weight object
            mGoalWeight = new GoalWeight(goalWeightVal, mUsername);

            //add goal weight to db
            mWeightTrackerDB.addGoalWeight(mGoalWeight);
        }
        // if user does already have a goal weight
        else {
            // Update Goal Weight object
            mGoalWeight.setGoalWeightValue(goalWeightVal);

            //save to db
            mWeightTrackerDB.updateGoalWeight(mGoalWeight);
        }

        finish();
    }

}