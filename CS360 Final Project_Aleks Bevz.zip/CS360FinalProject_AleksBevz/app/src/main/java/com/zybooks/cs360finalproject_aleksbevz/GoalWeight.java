// This file is for the GoalWeight class, which defines the structure of a GoalWeight object
//   as well as the methods which may be used on a GoalWeight Object.
//     The GoalWeight object holds all pertinent data that is associated with a user's goal weight.

package com.zybooks.cs360finalproject_aleksbevz;

public class GoalWeight {

    // Private long mId;
    private String mGoalWeightValue;
    private String mUsername;

    public GoalWeight() {}

    //constructor for goal weight objects
    public GoalWeight(String weight, String username) {
        mGoalWeightValue = weight;
        mUsername = username;
    }

    // various methods used to set or get any of the parameters associated with a single GoalWeight object
    public void setGoalWeightValue(String weight) {
        mGoalWeightValue = weight;
    }

    public String getGoalWeightValue() {
        return mGoalWeightValue;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getUsername() {
        return mUsername;
    }
}
